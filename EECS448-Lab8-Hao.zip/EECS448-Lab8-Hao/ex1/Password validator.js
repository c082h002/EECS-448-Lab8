

function validation()
{
    var enter = document.getElementById("Enter").value;
    var confirm = document.getElementById("Confirm").value;
    if(enter.length >= "8")
    {
        if(enter === confirm) 
        {
            alert(enter);
            alert("Password is valid");
        }
        else 
        {
            alert("Password is NOT valid");
        }
    }
    else
        {
          alert("The passwords are not at least 8 characters long");
        }   
    
}